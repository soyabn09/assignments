﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>
<?php #Script 1.0 - handle_form_logging.php
//Handles data from an HTML form and logs to a text file.
$firstName = $_REQUEST['firstName'];
$lastName = $_REQUEST['lastName'];
$email = $_REQUEST['email'];
$_firstName = array();//Note the underscore  to make it different from the variable.
$_lastName = array();
$_email = array(); 

$arraySize = count($_firstName);
echo $arraySize;
$newArraySize = $arraySize +1;
//echo "<p>New array size is $newArraySize</p>";
//$_firstName[] = $firstName;
//echo "<p>$_firstName[0]</p>";
//echo "<p>$_firstName[1]</p>";



//*******************************************************************
//*************  Writes to a text file in CSV format.  **************
//*******************************************************************
$myFile = "testFile.txt"; //names the text file
$fh = fopen($myFile, 'a') or die("can't open file");//Opens a connection to the file
$stringData = $firstName.",".$lastName.",".$email.PHP_EOL;
fwrite($fh, $stringData);//Writes $stringData to the text file
fclose($fh);


//*******************************************************************
//******* Outputs a line of the file until the end is reached *******
//*******************************************************************
//Opens file and reads a line of test at a time.
$fh = fopen($myFile, 'r');

  $counter = 0;
//echo "counter before the loop ".$counter.'<br>';

//Runs a loop for as many lines of data in the text file
while(! feof($fh))//Loop runs while it is not at end of file
  {

  $theData = fgets($fh);//Reads the whole length of the file line by line
//echo $theData;
  $_pieces = explode(',', $theData);//explode breaks the file up on the commas

  //print_r($_pieces);
  //Assigns the split up line to different arrays.
  $_firstName[$counter] = $_pieces[0];
  echo $_firstName[$counter];
  $_lastName[$counter] = $_pieces[1];
  //array_push($_lastName, $_pieces[1]);
//echo $_pieces[1];
  echo $_lastName[$counter];
  $_email[$counter] = $_pieces[2];
  echo $_email[$counter];
  echo '<br>';

  $counter=$counter + 1;
  }

fclose($fh);

//Display the content.
//echo $_pieces[0]; // piece1
//echo $_pieces[1]; // piece2


/*
//Create and validate the gender variable.
if (isset($_REQUEST	['gender'])) {
	$gender = $_REQUEST['gender'];
	}
else{
  $gender = NULL;
}  
*/		


//Print the submitted information
echo "<p>Thank you, $firstName, for sending your details</p>
<p>We will reply to you at
$email</p>\n";
?>

</body>
</html>