<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>U27 - P2</title>
</head>



<body>
    <h1>Criteria P2</h1>
    <br />
    <a href="../index.html">Home</a> 
    <br />
    <p>Use web server scripting to identify a user’s browser and screen resolution.</p>
    <a href="https://www.youtube.com/watch?v=mevwawdI_Qw">Criteria P2 YouTube video</a> 
    <br />
    <br />

    
    <?php


    function get_browser_type() {
        $_user_agent = $_SERVER['HTTP_USER_AGENT'];
        

        $broswer_type = "";

        if (preg_match('/MSIE/i',$_user_agent)) {
            $broswer_type="Internet Explorer";
        }
        elseif(preg_match('/firefox/i', $_user_agent)) {
            $broswer_type="Firefox";
        }
        elseif(preg_match('/chrome/i', $_user_agent)) {
            $broswer_type="Chrome";
        }
        elseif(preg_match('/edge/i', $_user_agent)) {
            $broswer_type="Edge";
        }    
        return $broswer_type;   
    }
    
    print"The browser you are using is ";
        echo get_browser_type();

        ?>

    <p id="height"></p>
    <p id="width"></p>
    <script>
        document.getElementById("width").innerHTML = "Your screen resolution is " + screen.width + " x " + screen.height;
    
    </script>

</body>
</html>