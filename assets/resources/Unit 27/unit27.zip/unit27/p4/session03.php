<?php
session_start();
if(isset($_SESSION['count']))
{
$_SESSION['count'] = $_SESSION['count'] + 1;
if($_SESSION['count'] > 10)
unset($_SESSION['count']); }
else
$_SESSION['count'] = 1;
?>
<html>
<head>
<title>Some web page</title>
</head>
<body>
<?php
if(isset($_SESSION['count']))
echo "Counter value = ".$_SESSION['count'];
else
echo "The counter does not currently have a value!";
?>
</body>
</html>