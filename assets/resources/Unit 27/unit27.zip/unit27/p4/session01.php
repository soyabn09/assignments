<?php
session_start();
$_SESSION['count'] = 1;
?>
<html>
<head>
<title>Some web page</title>
</head>
<body>
<?php
$_SESSION['count'] = 1;
echo "Counter value =
".$_SESSION['count'];
?>
</body>
</html>