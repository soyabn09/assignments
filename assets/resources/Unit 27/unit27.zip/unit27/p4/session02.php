<?php
session_start();
if(isset($_SESSION['count']))
$_SESSION['count'] = $_SESSION['count'] + 1;
else
$_SESSION['count'] = 1;
?>
<html>
<head>
<title>Some web page</title>
</head>
<body>
<?php
echo "Counter value = ".$_SESSION['count'];
?>
</body>
</html>