<?php
    if($_FILES["file"] ["error"] >0) {
        echo "Error: ".$FilES["files"] ["error"];
    } else {
        echo "File Name: ".$_FILES["file"] ["name"]."<br />";
        echo "File Type: ".$_FILES["file"] ["type"]."<br />";
        echo "File Size: ".$_FILES["file"] ["size"]."<br />";
        echo "File Location: ".$_FILES["file"] ["tmp_name"]."<br />";        
    }



    ?>